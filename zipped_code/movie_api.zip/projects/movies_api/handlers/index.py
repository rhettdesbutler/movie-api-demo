

def handler(event, context):

    print("Hello world!")

    print("Here is the event: {} and context: {} data".format(event, context))
